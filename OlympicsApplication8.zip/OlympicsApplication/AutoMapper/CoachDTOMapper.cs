using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using OlympicsApplication.Models.Entity;
using OlympicsApplication.OlympicsDTO;

namespace OlympicsApplication.AutoMapper
{
    public class CoachDTOMapper : Profile
    {
        public CoachDTOMapper()
        {
            
        CreateMap<CoachViewModel, Coach>(); 
        }

    }
}