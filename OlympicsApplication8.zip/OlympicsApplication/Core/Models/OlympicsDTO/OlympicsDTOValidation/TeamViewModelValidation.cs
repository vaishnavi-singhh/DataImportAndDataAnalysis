using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FluentValidation;

namespace OlympicsApplication.OlympicsDTO.OlympicsDTOValidation
{
    public class TeamViewModelValidation : AbstractValidator<TeamViewModel>
    {
        public TeamViewModelValidation()
        {

            RuleFor(x => x.TeamName).NotEmpty().WithMessage("Username should not be left blank");
            RuleFor(x => x.Country).NotEmpty();
            RuleFor(x => x.PlayerName).NotEmpty();
            RuleFor(x => x.Rank).NotNull();
            RuleFor(x => x.Type).NotEmpty();
        }
    }

} 