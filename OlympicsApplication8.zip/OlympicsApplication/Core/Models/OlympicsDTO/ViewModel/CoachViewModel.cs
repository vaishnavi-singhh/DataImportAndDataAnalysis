using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OlympicsApplication.OlympicsDTO
{
    public class CoachViewModel
    {
         public int TeamId { get; set; }
        public string TeamName { get; set; }
        public string Sport {get; set;}
        public string Country { get; set; }
        public string CoachName { get; set; }
        public int CoachAge { get; set; }
    
    }
}