using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using OlympicsApplication.Models.Entity;
using Microsoft.EntityFrameworkCore.Metadata.Builders;


namespace OlympicsApplication.Models.EntityMapper
{
    public class CoachMapper
    {
        public CoachMapper(EntityTypeBuilder<Coach> entityTypeBuilder)
        {
            entityTypeBuilder.HasKey(p => p.CoachId);
            entityTypeBuilder.Property(p => p.CoachName).IsRequired();
            entityTypeBuilder.Property(p => p.CoachAge).IsRequired();

            entityTypeBuilder.HasOne(p => p.team).WithMany(t => t.coaches).HasForeignKey(p => p.TeamId);
        }
    }
}