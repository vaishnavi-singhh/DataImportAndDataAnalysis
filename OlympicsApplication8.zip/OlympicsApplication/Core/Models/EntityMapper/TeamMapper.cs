using System;
using OlympicsApplication.Models.Entity;
using Microsoft.EntityFrameworkCore.Metadata.Builders;


namespace OlympicsApplication.Models.EntityMapper
{
    public class TeamMapper
    {
        public TeamMapper(EntityTypeBuilder<Team> entityTypeBuilder)
        {
            entityTypeBuilder.HasKey(p => p.TeamId);
            entityTypeBuilder.Property(p => p.TeamName).IsRequired();
            entityTypeBuilder.Property(p => p.Country).IsRequired();

            entityTypeBuilder.HasOne(a => a.medals).WithOne(u => u.team).HasForeignKey<Medals>(m => m.TeamId);
        }
    }
}