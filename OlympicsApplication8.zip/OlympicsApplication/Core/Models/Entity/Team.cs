using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OlympicsApplication.Models.Entity
{
    public class Team : BaseEntity
    {   
         public List<Players> players {get; set;}
         public List<Coach> coaches {get; set;}
         public virtual Medals medals {get; set;}      

   }
}