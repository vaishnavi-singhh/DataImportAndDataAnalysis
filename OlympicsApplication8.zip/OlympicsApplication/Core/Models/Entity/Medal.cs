using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OlympicsApplication.Models.Entity
{
    public class Medals : BaseEntity
    {
          public int Rank { get; set; }
          public string Type { get; set; }
          public virtual Team team {get ;set;}
          
    }
}