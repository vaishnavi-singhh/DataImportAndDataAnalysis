using System;

namespace OlympicsApplication.Functionality
{
    public interface IOlympicsChartService
    {
        public Task<List<object>> GetTopCountries();
        public List<object> GetPlayersByCountryAndSport();
        public List<object> GetMedalData();
        public List<object> GetMedalsByCountry();
        public List<object> GetPlayerCountBySport();
        public List<object> GetGenderCount();

    }
}