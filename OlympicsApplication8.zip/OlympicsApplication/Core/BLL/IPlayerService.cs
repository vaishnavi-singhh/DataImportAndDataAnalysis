using System;
using OlympicsApplication.OlympicsDTO;
using OlympicsApplication.Models.Entity;


namespace OlympicsApplication.Functionality
{
    public interface IPlayerService
    {
        public int? AddPlayer(PlayerViewModel playerViewModel);
        List<Players> GetPlayers();
        public System.Object FetchPlayerbyid(int id);
        public int DeletePlayer(int id);
        public int UpdatePlayer(PlayerViewModel playerViewModel);
        void SavePlayers(List<Players> players);

    }
}