using System;
using OlympicsApplication.Models.Entity;
using OlympicsApplication.OlympicsDTO;

namespace OlympicsApplication.Functionality
{
    public interface IMedalService
    {
        List<MedalViewModel> GetMedal();

        Task<MedalViewModel> GetMedal(int id);

        public int? AddMedal(MedalViewModel medalViewModel);

        int DeleteMedal(int id);
        public int UpdateMedal(MedalViewModel medalViewModel);

        void SaveMedal(List<Medals> medals);
    }
}