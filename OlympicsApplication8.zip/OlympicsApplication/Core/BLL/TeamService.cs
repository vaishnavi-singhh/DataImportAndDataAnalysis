using System;
using OlympicsApplication.Models.Entity;
using OlympicsApplication.OlympicsDTO;
using OlympicsApplication.Database;


namespace OlympicsApplication.Functionality
{
    public class TeamService : ITeamService
    {
        private readonly OlympicsDbContext olympicsDbContext;
        public TeamService(OlympicsDbContext _olympicsDbContext)
        {
            olympicsDbContext = _olympicsDbContext;
        }
        int ITeamService.AddTeam(TeamViewModel teamViewModel)
        {
            int Id = 0;

            Team objTeam = new Team();
            objTeam.TeamName = teamViewModel.TeamName;
            objTeam.Country = teamViewModel.Country;

            olympicsDbContext.Teams.Add(objTeam);
            olympicsDbContext.SaveChanges();

            Id = objTeam.TeamId;

            Players objPlayer = new Players();
            objPlayer.PlayerName = teamViewModel.PlayerName;
            objPlayer.TeamId = Id;

            olympicsDbContext.Players.Add(objPlayer);
            olympicsDbContext.SaveChanges();

            Coach objCoach = new Coach();
            objCoach.CoachName = teamViewModel.CoachName;
            objCoach.TeamId = Id;

            olympicsDbContext.Coaches.Add(objCoach);
            olympicsDbContext.SaveChanges();

            Medals objMedal = new Medals();
            objMedal.Rank = teamViewModel.Rank;
            objMedal.Type = teamViewModel.Type;
            objMedal.TeamId = Id;

            olympicsDbContext.Medals.Add(objMedal);
            return olympicsDbContext.SaveChanges();

        }

        List<Team> ITeamService.GetTeams()
        {

            return olympicsDbContext.Teams.ToList();
        }

        void ITeamService.SaveTeams(List<Team> teams)
        {
            olympicsDbContext.Teams.AddRange(teams);
            olympicsDbContext.SaveChanges();
        }
    }
}