using OlympicsApplication.Models.Entity;
using OlympicsApplication.Database;
using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;

namespace OlympicsApplication.Functionality
{
    public class ExcelReaderService : IExcelReaderService
    {
        private readonly OlympicsDbContext _context;

        public ExcelReaderService(OlympicsDbContext context)
        {
            _context = context;
        }

        public IEnumerable<string> ReadColumns(string filepath, string extn, bool isDownloadAction = false)
        {
            var columnNames = new List<string>();

            IWorkbook workbook;

            using (FileStream stream = new FileStream(filepath, FileMode.Open, FileAccess.Read))
            {
                if (extn == ".xls")
                {
                    workbook = new HSSFWorkbook(stream);
                }
                else
                {
                    workbook = new XSSFWorkbook(stream);
                }
            }

            ISheet sheet = workbook.GetSheetAt(0);

            IRow headerRow = sheet.GetRow(0);
            if (headerRow == null) throw new InvalidDataException("File is empty");
            foreach (ICell headerCell in headerRow)
            {
                if (!isDownloadAction)
                    columnNames.Add(headerCell.ToString().Trim().ToLower());
                else
                    columnNames.Add(headerCell.ToString().Trim());
            }

            return columnNames.AsEnumerable();
        }

        public IEnumerable<Team> ReadData(string filepath, string extn)
        {
            IWorkbook workbook;
            var teams = new List<Team>();

            using (FileStream stream = new FileStream(filepath, FileMode.Open, FileAccess.Read))
            {
                if (extn == ".xls")
                {
                    workbook = new HSSFWorkbook(stream);
                }
                else
                {
                    workbook = new XSSFWorkbook(stream);
                }
            }

            ISheet sheet = workbook.GetSheetAt(0);

            var rows = new List<string>();

            IRow headerRow = sheet.GetRow(0);
            foreach (ICell headerCell in headerRow)
            {
                rows.Add(headerCell.ToString().Trim().ToLower());
            }

            int rowIndex = 0;

            foreach (IRow row in sheet)
            {
                if (rowIndex++ == 0) continue; // skip header row

                var teamData = row.Cells.Select(c => c.ToString().Trim()).ToList();

                if (teamData.Count == 0)
                {
                    continue;
                }
                else
                {
                    var team = new Team
                    {
                        TeamName = row.GetCell(rows.FindIndex(x => x == "TeamName".ToLower()))?.ToString().Trim(),
                        Country = row.GetCell(rows.FindIndex(x => x == "Country".ToLower()))?.ToString().Trim(),
                        Sport = row.GetCell(rows.FindIndex(x => x == "Sport".ToLower()))?.ToString().Trim(),
                    };

                    teams.Add(team);

                    foreach (var columnName in _context.Teams.First().GetType().GetProperties().Select(p => p.Name))
                    {
                        var index = rows.FindIndex(x => x == columnName.ToLower());
                        if (index >= 0)
                        {
                            var cellValue = row.GetCell(index)?.ToString().Trim();
                            if (!string.IsNullOrEmpty(cellValue))
                            {
                                var propertyInfo = typeof(Team).GetProperty(columnName);
                                propertyInfo.SetValue(team, Convert.ChangeType(cellValue, propertyInfo.PropertyType));
                            }
                        }
                    }
                }
            }

            return teams.AsEnumerable();
        }

        public object ReadData(string path, object extn)
        {
            throw new System.NotImplementedException();
        }
    }
}
