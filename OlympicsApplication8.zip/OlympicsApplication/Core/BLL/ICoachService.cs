using System;
using OlympicsApplication.Models.Entity;

namespace OlympicsApplication.Functionality
{
    public interface ICoachService
    {
        int? AddCoach(Coach coach);
        Coach GetCoachSingleRecord(int id);
        List<Coach> GetCoachRecords();
        void SaveCoach(List<Coach> coaches);

    }
}