using System;
using OlympicsApplication.Models.Entity;

namespace OlympicsApplication.Functionality
{
    public interface IExcelPlayerReader
    {
        IEnumerable<string> ReadColumns(string filepath, string extn, bool isDownloadAction = false);

        IEnumerable<Players> ReadData(string filepath, string extn);
        object ReadData(string path, object extn);
    }
}