using FluentValidation;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;
using OlympicsApplication.Database;
using OlympicsApplication.Functionality;
using OlympicsApplication.OlympicsDTO;
using OlympicsApplication.OlympicsDTO.OlympicsDTOValidation;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<OlympicsDbContext>(t => t.UseNpgsql(builder.Configuration.GetConnectionString("MyConnection")));

// Add services to the container. 

builder.Services.AddControllers();
builder.Services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
builder.Services.AddCors();
builder.Services.AddTransient<ITeamService, TeamService>();
builder.Services.AddTransient<IPlayerService, PlayerService>();
builder.Services.AddTransient<ICoachService, CoachService>();
builder.Services.AddTransient<IMedalService, MedalService>();
builder.Services.AddTransient<IExcelPlayerReader, PlayerReader>();
builder.Services.AddTransient<IExcelMedalReaderService, MedalReader>();
builder.Services.AddTransient<IExcelReaderService, ExcelReaderService>();
builder.Services.AddTransient<IExcelCoachReaderService, CoachReader>();
builder.Services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
builder.Services.AddScoped<IValidator<TeamViewModel>, TeamViewModelValidation>();
builder.Services.AddScoped<IOlympicsChartService, OlympicsChartService>();

builder.Services.AddControllersWithViews().AddNewtonsoftJson(options => options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore);
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "olympicsapplication", Version = "v1" });
            });

var app = builder.Build();

app.UseCors(x => x
              .AllowAnyMethod()
              .AllowAnyHeader()
              .SetIsOriginAllowed(origin => true)
              .AllowCredentials());

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "olympicsapplication v1"));
}
app.UseStaticFiles();

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
