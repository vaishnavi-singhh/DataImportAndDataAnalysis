using System;
using Microsoft.AspNetCore.Mvc;
using OlympicsApplication.Functionality;
using OlympicsApplication.OlympicsDTO;
using AutoMapper;
using OlympicsApplication.Models.Entity;

namespace OlympicsApplication.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CoachController : ControllerBase
    {
        IMapper imapper;
        ICoachService iCoachService;
        private IWebHostEnvironment hostEnvironment;

        private IHttpContextAccessor httpContextAccessor;

        private object mapper;

        public CoachController(ICoachService _iCoachService, IMapper _imapper, IWebHostEnvironment _hostEnvironment, IHttpContextAccessor _httpContextAccessor)
        {
            imapper = _imapper;
            iCoachService = _iCoachService;
            hostEnvironment = _hostEnvironment;
            httpContextAccessor = _httpContextAccessor;
        }

        [HttpPost()]
        public IActionResult PostAddCoach([FromBody] CoachViewModel coachViewModel)
        { //applying by automapper
            var obj = imapper.Map<Coach>(coachViewModel);
            return Ok(iCoachService.AddCoach(obj));
        }

        [HttpGet()]
        public IActionResult GetCoachDetails()
        {
            return Ok(iCoachService.GetCoachRecords());
        }

        [HttpGet("{id}")]
        public IActionResult GetFetchSpecificEmployee(int id)
        {
            return Ok(iCoachService.GetCoachSingleRecord(id));
        }

        [Produces("application/json")]
        [HttpPost("upload")]
        public IActionResult Upload(IFormFile file)
        {
            try
            {
                var path = Path.Combine(hostEnvironment.WebRootPath, "uploads", file.FileName);
                using (var fileStream = new FileStream(path, FileMode.Create))
                {
                    file.CopyTo(fileStream);
                }
                var baseURL = httpContextAccessor.HttpContext.Request.Scheme + "://" +
                httpContextAccessor.HttpContext.Request.Host + httpContextAccessor.HttpContext.Request.PathBase;
                return Ok(new
                {
                    fileName = Path.Combine(baseURL, "/uploads", file.FileName)
                });
            }

            catch
            {
                return BadRequest();
            }


        }

    }
}