using System;
using Microsoft.AspNetCore.Mvc;
using OlympicsApplication.Functionality;
using OlympicsApplication.OlympicsDTO;
using OlympicsApplication.Database;

namespace OlympicsApplication.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PlayerController : ControllerBase
    {
        IPlayerService iPlayerService;
        private readonly OlympicsDbContext olympicsDbContext;
         private IWebHostEnvironment hostEnvironment;

        private IHttpContextAccessor httpContextAccessor;

        public PlayerController(IPlayerService _iPlayerService, OlympicsDbContext _olympicsDbContext,IWebHostEnvironment _hostEnvironment, IHttpContextAccessor _httpContextAccessor)
        {

            iPlayerService = _iPlayerService;
            olympicsDbContext = _olympicsDbContext;
             hostEnvironment = _hostEnvironment;
            httpContextAccessor = _httpContextAccessor;
        }

        [HttpPost("CreatePlayer")]
        public IActionResult CreatePlayer([FromBody] PlayerViewModel viewModel)
        {
            return Ok(iPlayerService.AddPlayer(viewModel));
        }

        [HttpGet("{id}")]
        public IActionResult FetchplayerbyID(int id)
        {
            return Ok(iPlayerService.FetchPlayerbyid(id));
        }

        [HttpGet]
        [Route("getplayer")]
        public async Task<IActionResult> Fetchplayer()
        {
          return Ok(iPlayerService.GetPlayers());
        }

        [HttpDelete("{id}")]
        public IActionResult Deleteplayer(int id)
        {
            return Ok(iPlayerService.DeletePlayer(id));
        }

      

         [HttpPut("UpdatePlayer")]
        public IActionResult UpdatePlayer([FromBody] PlayerViewModel viewModel)
        {
            return Ok(iPlayerService.UpdatePlayer(viewModel));
        }  

          [Produces("application/json")]
        [HttpPost("upload")]
        public IActionResult Upload(IFormFile file)
        {
            try
            {
                var path = Path.Combine(hostEnvironment.WebRootPath, "uploads", file.FileName);
                using (var fileStream = new FileStream(path, FileMode.Create))
                {
                    file.CopyTo(fileStream);
                }
                var baseURL = httpContextAccessor.HttpContext.Request.Scheme + "://" +
                httpContextAccessor.HttpContext.Request.Host + httpContextAccessor.HttpContext.Request.PathBase;
                return Ok(new
                {
                    fileName = Path.Combine(baseURL, "/uploads", file.FileName)
                });
            }

            catch
            {
                return BadRequest();
            }


        }
    }
}
