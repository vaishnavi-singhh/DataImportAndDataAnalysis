using System;
using Microsoft.AspNetCore.Mvc;
using OlympicsApplication.Functionality;
using FluentValidation;
using OlympicsApplication.OlympicsDTO;

namespace OlympicsApplication.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TeamController : ControllerBase
    {
           private readonly ITeamService _teamService;
          private readonly IValidator<TeamViewModel> _validator;
          private IWebHostEnvironment hostEnvironment;

        private IHttpContextAccessor httpContextAccessor;
        public TeamController(IValidator<TeamViewModel> validator, ITeamService teamService,IWebHostEnvironment _hostEnvironment, IHttpContextAccessor _httpContextAccessor)
        {
            _validator = validator;
            _teamService = teamService;
             hostEnvironment = _hostEnvironment;
            httpContextAccessor = _httpContextAccessor;
        }

        [HttpGet]
        public  IActionResult FetchTeams()
        {
            return Ok(_teamService.GetTeams());
        }


        [HttpPost]
        public IActionResult CreateTeams(TeamViewModel teamViewModel)
        {
            var validationResult = _validator.Validate(teamViewModel);
            if (validationResult.IsValid)  
            {
                return Ok(_teamService.AddTeam(teamViewModel));
            }
            return BadRequest();  
        }


        [Produces("application/json")]
        [HttpPost("upload")]
        public IActionResult Upload(IFormFile file)
        {
            try
            {
                var path = Path.Combine(hostEnvironment.WebRootPath, "uploads", file.FileName);
                using (var fileStream = new FileStream(path, FileMode.Create))
                {
                    file.CopyTo(fileStream);
                }
                var baseURL = httpContextAccessor.HttpContext.Request.Scheme + "://" +
                httpContextAccessor.HttpContext.Request.Host + httpContextAccessor.HttpContext.Request.PathBase;
                return Ok(new
                {
                    fileName = Path.Combine(baseURL, "/uploads", file.FileName)
                });
            }

            catch
            {
                return BadRequest();
            }


        }
    }
}