using System;
using Microsoft.AspNetCore.Mvc;
using OlympicsApplication.Functionality;
using OlympicsApplication.Models.Entity;
using OlympicsApplication.Database;

namespace OlympicsApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MedalExcelReaderController : ControllerBase
    {
        private readonly IExcelMedalReaderService _excelReaderService;

        private readonly IMedalService _medalService;
        private readonly OlympicsDbContext _dbContext;

        public MedalExcelReaderController(IExcelMedalReaderService excelReaderService,OlympicsDbContext dbContext, IMedalService medalService)
        {
            _excelReaderService = excelReaderService;
            _dbContext = dbContext;

            _medalService = medalService;
        }

        [HttpPost("upload")]
        public IActionResult Upload(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                return BadRequest("File is empty");
            }

            var extn = Path.GetExtension(file.FileName);

            if (extn != ".xls" && extn != ".xlsx")
            {
                return BadRequest("Invalid file type");
            }

            var filepath = Path.GetTempFileName();

            using (var stream = new FileStream(filepath, FileMode.Create))
            {
                file.CopyTo(stream);
            }

            var columns = _excelReaderService.ReadColumns(filepath, extn, true);
            var data = _excelReaderService.ReadData(filepath, extn);
            var MedalList = new List<Medals>();
            try
            {
                foreach (var row in data)
                {
                    var medal = new Medals
                    {
                        TeamName = row.TeamName,
                        Country = row.Country,
                        Sport = row.Sport,
                        TeamId = row.TeamId,
                        Rank = row.Rank,
                        Type = row.Type
                    };
                    MedalList.Add(medal);
                }

                    _medalService.SaveMedal(MedalList);
            }
            catch (Exception ex)
            {
                // Handle any exceptions that occur during database operations
                return StatusCode(500, $"An error occurred while saving data to the database: {ex.Message}");
            }

            return Ok(new { Columns = columns, Data = data });
        }
    }
}



