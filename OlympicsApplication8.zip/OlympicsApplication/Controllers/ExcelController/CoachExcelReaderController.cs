using System;
using Microsoft.AspNetCore.Mvc;
using OlympicsApplication.Functionality;
using OlympicsApplication.Models.Entity;
using OlympicsApplication.Database;

namespace OlympicsApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CoachExcelReaderController : ControllerBase
    {
        private readonly IExcelCoachReaderService _excelReaderService;

        private readonly ICoachService _coachService;
        private readonly OlympicsDbContext _dbContext;

        public CoachExcelReaderController(IExcelCoachReaderService excelReaderService,OlympicsDbContext dbContext, ICoachService coachService)
        {
            _excelReaderService = excelReaderService;
            _dbContext = dbContext;

            _coachService = coachService;
        }

        [HttpPost("upload")]
        public IActionResult Upload(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                return BadRequest("File is empty");
            }

            var extn = Path.GetExtension(file.FileName);

            if (extn != ".xls" && extn != ".xlsx")
            {
                return BadRequest("Invalid file type");
            }

            var filepath = Path.GetTempFileName();

            using (var stream = new FileStream(filepath, FileMode.Create))
            {
                file.CopyTo(stream);
            }

            var columns = _excelReaderService.ReadColumns(filepath, extn, true);
            var data = _excelReaderService.ReadData(filepath, extn);
            var CoachList = new List<Coach>();
            try
            {
                foreach (var row in data)
                {
                    var coach = new Coach
                    {
                        CoachName = row.CoachName,
                        TeamName = row.TeamName,
                        Country = row.Country,
                        Sport = row.Sport,
                        CoachAge = row.CoachAge,
                        TeamId = row.TeamId
                    };
                    CoachList.Add(coach);
                }

                    _coachService.SaveCoach(CoachList);
            }
            catch (Exception ex)
            {
                // Handle any exceptions that occur during database operations
                return StatusCode(500, $"An error occurred while saving data to the database: {ex.Message}");
            }

            return Ok(new { Columns = columns, Data = data });
        }
    }
}
