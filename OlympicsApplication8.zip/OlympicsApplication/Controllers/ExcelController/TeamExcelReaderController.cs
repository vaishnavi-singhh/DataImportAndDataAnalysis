using System;
using Microsoft.AspNetCore.Mvc;
using OlympicsApplication.Functionality;
using OlympicsApplication.Models.Entity;
using OlympicsApplication.Database;

namespace OlympicsApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TeamExcelReaderController : ControllerBase
    {
             private readonly IExcelReaderService _excelReaderService;

            private readonly ITeamService _teamService;
            private readonly OlympicsDbContext _dbContext;

            public TeamExcelReaderController(IExcelReaderService excelReaderService,OlympicsDbContext dbContext, ITeamService teamService)
            {
                _excelReaderService = excelReaderService;
                _dbContext = dbContext;

                _teamService = teamService;
            }

            [HttpPost("upload")]
            public IActionResult Upload(IFormFile file)
            {
                if (file == null || file.Length == 0)
                {
                    return BadRequest("File is empty");
                }

                var extn = Path.GetExtension(file.FileName);

                if (extn != ".xls" && extn != ".xlsx")
                {
                    return BadRequest("Invalid file type");
                }

                var filepath = Path.GetTempFileName();

                using (var stream = new FileStream(filepath, FileMode.Create))
                {
                    file.CopyTo(stream);
                }

                var columns = _excelReaderService.ReadColumns(filepath, extn, true);
                var data = _excelReaderService.ReadData(filepath, extn);
                var TeamsList = new List<Team>();
                try
                {
                    foreach (var row in data)
                    {
                        var team = new Team
                        {
                            TeamName = row.TeamName,
                            Country = row.Country,
                            Sport = row.Sport
                        };
                        TeamsList.Add(team);
                    }

                        _teamService.SaveTeams(TeamsList);
                }
                catch (Exception ex)
                {
                    // Handle any exceptions that occur during database operations
                    return StatusCode(500, $"An error occurred while saving data to the database: {ex.Message}");
                }

                return Ok(new { Columns = columns, Data = data });
            }
        }
}
      
