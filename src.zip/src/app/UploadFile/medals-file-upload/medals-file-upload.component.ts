import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-medals-file-upload',
  templateUrl: './medals-file-upload.component.html',
  styleUrls: ['./medals-file-upload.component.css']
})
export class MedalsFileUploadComponent implements OnInit {

  fileUploadUrl = "http://localhost:5141/api/MedalExcelReader/upload";

  constructor(private _http: HttpClient, private toastr: ToastrService,private router: Router ) {}

  ngOnInit(): void {}

  file: any;

  selectFile(event: any) {
    this.file = event.target.files[0];
    console.log(this.file);
  }
 
  navigateToMedals(): void {
    this.router.navigate(['/FetchMedalsData']);
  }  


  async uploadFile() {
    let formData = new FormData();
    formData.append("file", this.file);
  
    console.log(this.file);
  
    try {
      const result = await this._http
        .post<any>(this.fileUploadUrl, formData)
        .toPromise();
      console.log(result);
      this.toastr.success("File uploaded successfully");
    } catch (error) {
      console.log(error);
      this.toastr.error("File upload failed");
    }
  }
  
}
