import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MedalsFileUploadComponent } from './medals-file-upload.component';

describe('MedalsFileUploadComponent', () => {
  let component: MedalsFileUploadComponent;
  let fixture: ComponentFixture<MedalsFileUploadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MedalsFileUploadComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MedalsFileUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
