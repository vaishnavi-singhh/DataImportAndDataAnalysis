import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-coaches-file-upload',
  templateUrl: './coaches-file-upload.component.html',
  styleUrls: ['./coaches-file-upload.component.css']
})
export class CoachesFileUploadComponent {
  fileUploadUrl = "http://localhost:5141/api/CoachExcelReader/upload";

  constructor(private _http: HttpClient, private toastr: ToastrService, private router : Router) {}

  file: any;

  selectFile(event: any) {
    this.file = event.target.files[0];
    console.log(this.file);
  }
 
  navigateToCoaches(): void {
    this.router.navigate(['/FetchCoachData']);
  }  

  uploadFile() {
    let formData = new FormData();
    formData.append("file", this.file);

    console.log(this.file);

    this._http.post(this.fileUploadUrl, formData).subscribe(
      (data) => {
        console.log(data);
        this.toastr.success("File uploaded successfully");
      },
      (error) => {
        console.log(error);
        this.toastr.error("File upload failed");
      }
    );
  }
}
