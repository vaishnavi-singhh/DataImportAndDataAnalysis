import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CoachesFileUploadComponent } from './coaches-file-upload.component';

describe('CoachesFileUploadComponent', () => {
  let component: CoachesFileUploadComponent;
  let fixture: ComponentFixture<CoachesFileUploadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CoachesFileUploadComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CoachesFileUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
