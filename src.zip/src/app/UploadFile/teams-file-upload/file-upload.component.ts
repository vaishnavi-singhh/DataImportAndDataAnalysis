import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.css']
})

export class FileUploadComponent implements OnInit {
  fileUploadUrl = "http://localhost:5141/api/Team/upload";
  allowedFileTypes = ['application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];
  file: any;

  constructor(private _http: HttpClient, private toastr: ToastrService, private router: Router) { }

  ngOnInit(): void { }

  selectFile(event: any) {
    const selectedFile = event.target.files[0];
    if (selectedFile && this.allowedFileTypes.includes(selectedFile.type)) {
      this.file = selectedFile;
      console.log(this.file);
    } else {
      this.toastr.error('Only Excel files are allowed');
      event.target.value = null; // Reset the file input value
    }
  }

  async uploadFile() {
    if (!this.file) {
      this.toastr.error('Please select a file');
      return;
    }

    let formData = new FormData();
    formData.append("file", this.file);

    console.log(this.file);

    try {
      const result = await this._http
        .post<any>(this.fileUploadUrl, formData)
        .toPromise();
      console.log(result);
      this.toastr.success('File uploaded successfully');
    } catch (error) {
      this.toastr.error('An error occurred while uploading the file');
      console.log(error);
    }
  }

  navigateToTeams(): void {
    this.router.navigate(['/FetchTeamsData']);
  }
}
