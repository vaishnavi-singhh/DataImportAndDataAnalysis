import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PlayersFileUploadComponent } from './players-file-upload.component';

describe('PlayersFileUploadComponent', () => {
  let component: PlayersFileUploadComponent;
  let fixture: ComponentFixture<PlayersFileUploadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PlayersFileUploadComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PlayersFileUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
