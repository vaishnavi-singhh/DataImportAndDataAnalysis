import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-players-file-upload',
  templateUrl: './players-file-upload.component.html',
  styleUrls: ['./players-file-upload.component.css']
})
export class PlayersFileUploadComponent implements OnInit {
  fileUploadUrl = "http://localhost:5141/api/Player/upload";
  allowedFileTypes = ['application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];
  file: any;

  constructor(private _http: HttpClient, private toastr: ToastrService, private router: Router) {}

  ngOnInit(): void {}

  selectFile(event: any) {
    const selectedFile = event.target.files[0];
    if (selectedFile && this.allowedFileTypes.includes(selectedFile.type)) {
      this.file = selectedFile;
      console.log(this.file);
    } else {
      this.toastr.error('Only Excel files are allowed');
      event.target.value = null; // Reset the file input value
    }
  }

  navigateToPlayers(): void {
    this.router.navigate(['/FetchPlayersData']);
  }

  async uploadFile() {
    if (!this.file) {
      this.toastr.error('Please select a file');
      return;
    }

    let formData = new FormData();
    formData.append("file", this.file);

    console.log(this.file);

    try {
      const result = await this._http
        .post<any>(this.fileUploadUrl, formData)
        .toPromise();
      console.log(result);
      this.toastr.success('File uploaded successfully');
    } catch (error) {
      this.toastr.error('An error occurred while uploading the file');
      console.log(error);
    }
  }
}
