import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'OlympicsApp';

  ngOnInit() 
  {
    
  }


  myimage:string = "C:\Vaishnavi\olympicappang\download.jfif";

  openGraph() {
    const navContainer = document.querySelector('.chart-nav-container');
    navContainer?.classList.toggle('show');
  }
  
}
