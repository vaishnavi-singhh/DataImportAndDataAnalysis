import { Component, OnInit, AfterViewInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Chart, PieController,ArcElement, CategoryScale, Title, Tooltip, ChartOptions, ChartType } from 'chart.js';
Chart.register(ArcElement);

@Component({
  selector: 'app-pie-chart',
  template: `
    <div>
      <canvas id="myChart"></canvas>
    </div>
  `,
  styles: [
    `
      div {
        display: flex;
        flex-direction: column;
        align-items: center;
      }

      canvas {
        height: 400px !important;
        max-width: 700px;
      }
    `
  ],
})
export class PieChartComponent implements OnInit, AfterViewInit {
  chartData: number[] = [];
  chartLabels: string[] = [];
  chartType = 'pie';
  chartLegend = true;
  chartOptions: ChartOptions = {
    responsive: true,
  };
  chart: any;

  constructor(private http: HttpClient) {
    Chart.register(PieController, CategoryScale, Title, Tooltip);
  }
   
  ngOnInit(): void {
    this.http.get<any[]>('http://localhost:5141/api/TopCountries/api/players/count-by-sport').subscribe((data) => {
      data.sort((a, b) => b.count - a.count); // sort the data in descending order by value
      const topNations = data.slice(0, 5); // get the top 5 countries with maximum participation
      const addedLabels = new Set<string>();
      topNations.forEach((item) => {
        const label = item.sport?.toLowerCase();
        if (label && !addedLabels.has(label)) {
          this.chartData.push(item.count);
          this.chartLabels.push(label);
          addedLabels.add(label);
        }
      });
      this.createChart();
    });
  
    }


  ngAfterViewInit(): void {
  }

  createChart() {
    const canvas = document.getElementById('myChart') as HTMLCanvasElement;
    if (this.chart) {
      this.chart.destroy();
    }
    this.chart = new Chart(canvas, {
      type: this.chartType as ChartType,
      data: {
        labels: this.chartLabels,
        datasets: [
          {
            data: this.chartData,
            backgroundColor: [
              'rgba(255, 99, 132, 0.8)',
              'rgba(54, 162, 235, 0.8)',
              'rgba(255, 206, 86, 0.8)',
              'rgba(75, 192, 192, 0.8)',
              'rgba(153, 102, 255, 0.8)',
              'rgba(255, 159, 64, 0.8)',
            ],
            borderColor: [
              'rgba(255, 99, 132, 1)',
              'rgba(54, 162, 235, 1)',
              'rgba(255, 206, 86, 1)',
              'rgba(75, 192, 192, 1)',
              'rgba(153, 102, 255, 1)',
              'rgba(255, 159, 64, 1)',
            ],
            borderWidth: 1,
            hoverOffset: 4,
            spacing: 5,
          },
        ],
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'right',
          },
          title: {
            display: true,
            text: 'Sports With Maximum Participation',
            font: {
              size: 18,
            },
          },
        },
        elements: {
          arc: {
            borderWidth: 0
    
      },
    }
  }
    });
  }
  }



  