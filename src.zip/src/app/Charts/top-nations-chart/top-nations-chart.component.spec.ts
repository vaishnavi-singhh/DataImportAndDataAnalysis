import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TopNationsChartComponent } from './top-nations-chart.component';

describe('TopNationsChartComponent', () => {
  let component: TopNationsChartComponent;
  let fixture: ComponentFixture<TopNationsChartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TopNationsChartComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TopNationsChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
