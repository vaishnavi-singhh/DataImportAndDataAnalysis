import { Component, OnInit, AfterViewInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Chart, BarElement, BarController, CategoryScale, Decimation, Filler, Legend, Title, Tooltip, ChartOptions, ChartType, LinearScale } from 'chart.js';

@Component({
  selector: 'app-my-chart',
  template: `
    <div>
      <select [(ngModel)]="selectedSport" (ngModelChange)="onSportSelectionChange()">
        <option *ngFor="let sport of sports" [value]="sport">{{sport}}</option>
      </select>
      <canvas id="myChart"></canvas>
    </div>
  `,
  styles: [
    `
      div {
        display: flex;
        flex-direction: column;
        align-items: center;
      }

      canvas {
        height: 350px !important;
        max-width: 600px;
      }
    `
  ],
})
export class TopNationsChartComponent implements OnInit, AfterViewInit {
  chartData: number[] = [];
  chartLabels: string[] = [];
  chartType = 'bar';
  chartLegend = false;
  chartOptions: ChartOptions = {
    responsive: true,
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          stepSize: 1,
        },
      },
    },
  };
  allSportData: any = [];
  allSportLabels: any = [];

  sports: string[] = ['All', 'Badminton', 'Swimming','Wrestling', 'Boxing','Track Event','Shooting'];
  selectedSport: string = 'All';
  sportData: any;
  chart: any;

  constructor(private http: HttpClient) {
    Chart.register(BarElement, BarController, CategoryScale, Decimation, Filler, Legend, Title, Tooltip, LinearScale);
  }

  ngOnInit(): void {
    this.http.get<any[]>('http://localhost:5141/api/TopCountries').subscribe((data) => {
      data.sort((a, b) => b.playerCount - a.playerCount); // sort the data in descending order by value
      const topNations = data.slice(0, 5); // get the top 5 countries with maximum participation
      topNations.forEach((item) => {
        this.allSportData.push(item.playerCount);
        this.allSportLabels.push(item.country);
        this.chartData = this.allSportData;
        this.chartLabels = this.allSportLabels;
      });
      this.createChart();
    });
    this.getSportData();
  }

  getSportData() {
    this.http.get<any[]>('http://localhost:5141/api/TopCountries/players-by-country-and-sport').subscribe((data) => {
      this.sportData = data;
    });
  }

  ngAfterViewInit(): void {
  }

  onSportSelectionChange(): void {
    if (this.selectedSport === 'All') {
      this.chartData = this.allSportData;
      this.chartLabels = this.allSportLabels;
      this.createChart();
    } else {
      const sportData = this.sportData.filter((item: any) => item.sport === this.selectedSport);
      const sortedData = sportData.sort((a: any, b: any) => b.playerCount - a.playerCount).slice(0, 5);
      this.chartData = [];
      this.chartLabels = [];
      sortedData.forEach((item: any) => {
        this.chartData.push(item.playerCount);
        this.chartLabels.push(item.country);
      });
      this.createChart();
    }
  }

  createChart() {
    const canvas = document.getElementById('myChart') as HTMLCanvasElement;
    if (this.chart) {
      this.chart.destroy();
    }
    this.chart = new Chart(canvas, {
      type: this.chartType as ChartType,
      data: {
        labels: this.chartLabels,
        datasets: [
          {  
            label: 'Participation',
            data: this.chartData,
            backgroundColor: [
              'rgba(255, 99, 132, 0.2)',
              'rgba(54, 162, 235, 0.2)',
              'rgba(255, 206, 86, 0.2)',
            ],
            borderColor: [
              'rgba(255, 99, 132, 1)',
              'rgba(54, 162, 235, 1)',
              'rgba(255, 206, 86, 1)',
            ],
            borderWidth: 1,
          },
        ],
      },
      options: this.chartOptions,
    });
  }
  
          };