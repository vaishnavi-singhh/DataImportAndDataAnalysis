import { Component, OnInit, AfterViewInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Chart, BarElement, BarController, CategoryScale, Decimation, Filler, Legend, Title, Tooltip, ChartOptions, ChartType, LinearScale } from 'chart.js';

@Component({
  selector: 'app-gender-chart',
  template: `
    <div>
    <label for="sport-select">Filter by Sport:</label>
    <select [(ngModel)]="selectedSport" (change)="onSportSelectionChange()">
        <option *ngFor="let sport of sports" [value]="sport">{{sport}}</option>
      </select>
      <canvas id="myChart"></canvas>
    </div>
  `,
  styles: [
    `
      div {
        display: flex;
        flex-direction: column;
        align-items: center;
      }

      canvas {
        height: 350px !important;
        max-width: 600px;
      }
    `
  ],
})
export class GenderChartComponent implements OnInit, AfterViewInit {
  chartData: number[] = [];
  chartLabels: string[] = [];
  chartType = 'bar';
  chartLegend = false;
  chartOptions: ChartOptions = {
    responsive: true,
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          stepSize: 1,
        },
      },
    },
  };
  allSportData: any = [];
  allSportLabels: any = [];

  sports: string[] = ['All', 'Badminton', 'Swimming', 'Wrestling', 'Boxing', 'Track Event', 'Shooting'];
  selectedSport: string = 'All';
  sportData: any;
  chart: any;
  genderData: any;

  constructor(private http: HttpClient) {
    Chart.register(BarElement, BarController, CategoryScale, Decimation, Filler, Legend, Title, Tooltip, LinearScale);
  }

  ngOnInit(): void {
    this.http.get<any[]>('http://localhost:5141/api/TopCountries/gender-count').subscribe((data) => {
      let maleCount = 0;
      let femaleCount = 0;
      data.forEach((item) => {
        if (item?.gender && item?.gender.toLowerCase() === 'male')
          maleCount += item.count;
        else if (item?.gender && item?.gender.toLowerCase() === 'female')
          femaleCount += item.count;
      });
      this.allSportData = [maleCount, femaleCount];
      this.allSportLabels = ["Male", "Female"];
      this.chartData = this.allSportData;
      this.chartLabels = this.allSportLabels;
      this.sportData = data;

      this.createChart();
    });

  }

  ngAfterViewInit(): void {
  }

  onSportSelectionChange(): void {
    if (this.selectedSport === 'All') {
      this.chartData = this.allSportData;
      this.chartLabels = this.allSportLabels;
    } else {
      const sportData = this.sportData.filter((item: any) => {
        return item.sport && item.sport.toLowerCase() === this.selectedSport.toLowerCase();
      });

      const maleCount = sportData.reduce((total: number, item: any) => {
        if (item.gender && item.gender.toLowerCase() === 'male') {
          total += item.count;
        }
        return total;
      }, 0);

      const femaleCount = sportData.reduce((total: number, item: any) => {
        if (item.gender && item.gender.toLowerCase() === 'female') {
          total += item.count;
        }
        return total;
      }, 0);

      this.chartData = [maleCount, femaleCount];
      this.chartLabels = ['Male', 'Female'];
    }

    this.createChart();
  }


  createChart() {
    const canvas = document.getElementById('myChart') as HTMLCanvasElement;
    if (this.chart) {
      this.chart.destroy();
    }
    this.chart = new Chart(canvas, {
      type: this.chartType as ChartType,
      data: {
        labels: this.chartLabels,
        datasets: [
          {
            label: 'Gender',
            data: this.chartData,
            backgroundColor: [
              'rgba(255, 99, 132, 0.2)',
              'rgba(54, 162, 235, 0.2)',
            ],
            borderColor: [
              'rgba(255, 99, 132, 1)',
              'rgba(54, 162, 235, 1)',
            ],
            borderWidth: 1,
          },
        ],
      },
      options: {
        responsive: true,
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              stepSize: 1,
            },
          },
        },
      },
    });
  }


};
