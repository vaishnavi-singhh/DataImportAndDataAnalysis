import { Component, OnInit, AfterViewInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Chart, BarElement, BarController, CategoryScale, Decimation, Filler, Legend, Title, Tooltip, ChartOptions, ChartType, LinearScale } from 'chart.js';

@Component({
  selector: 'app-medals-chart',
  template: `
    <div>
    <label for="sport-select">Filter by Sport:</label>
      <select [(ngModel)]="selectedSport" (ngModelChange)="onSportSelectionChange()">
        <option *ngFor="let sport of sports" [value]="sport">{{sport}}</option>
      </select>
      <label for="medal-select">Filter by Medal Type:</label>
       <select [(ngModel)]="selectedMedal" (ngModelChange)="onMedalSelectionChange()">
        <option *ngFor="let medal of medals" [value]="medal">{{medal}}</option>
      </select> 
      <canvas id="myChart"></canvas>
    </div>
  `,
  styles: [
    `
      div {
        display: flex;
        flex-direction: column;
        align-items: center;
      }

      canvas {
    height: 350px !important;
    max-width: 600px;
} `
  ],
})
export class MedalsChartComponent implements OnInit, AfterViewInit {
  chartData: number[] = [];
  chartLabels: string[] = [];
  chartType = 'bar';
  chartLegend = false;
  chartOptions: ChartOptions = {
    responsive: true,
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          stepSize: 1,
        },
      },
    },
  };

  allSportData: any = [];
  allSportLabels: any = [];
  allMedalData: any = [];
  allMedalLabels: any = [];

  sports: string[] = ['All', 'Badminton', 'Swimming','Wrestling', 'Boxing','Track Event','Shooting'];
  selectedSport: string = 'All';
  sportData: any;

  medals: string[] = ['All', 'Gold', 'Silver', 'Bronze'];
  selectedMedal: string = 'All';
  medalData: any;

  chart: any;
  updateChartData: any;
  

  constructor(private http: HttpClient) {
    Chart.register(BarElement, BarController, CategoryScale, Decimation, Filler, Legend, Title, Tooltip, LinearScale);
  }

  ngOnInit(): void {
    this.http.get<any[]>('http://localhost:5141/api/TopCountries/medals-by-country').subscribe((data) => {
      data.sort((a, b) => b.totalMedals - a.totalMedals); // sort the data in descending order by value
      const topNations = data.slice(0, 5); // get the top 5 countries with maximum participation
      topNations.forEach((item) => {
        this.allSportData.push(item.totalMedals);
        this.allSportLabels.push(item.country);
        this.chartData = this.allSportData;
        this.chartLabels = this.allSportLabels;
        this.allMedalData = this.allSportData;
        this.allMedalLabels = this.allSportLabels;
      });
      this.createChart();
    });
    this.getMedalsData();
  }

  getMedalsData() {
    this.http.get<any[]>('http://localhost:5141/api/TopCountries/medals-count').subscribe((data) => {
      this.medalData = data;
    });
  }

  ngAfterViewInit(): void {
  }

  onSportSelectionChange(): void {
    if (this.selectedSport === 'All') {
      this.chartData = this.allSportData;
      this.chartLabels = this.allSportLabels;
      this.createChart();
    } else {
      const sportData = this.medalData.filter((item: any) => this.selectedMedal !== 'All' ? item.sport.toLowerCase() === this.selectedSport.toLowerCase() && item?.medalType.toLowerCase() === this.selectedMedal.toLowerCase() : item.sport.toLowerCase() === this.selectedSport.toLowerCase());
      const sortedData = sportData.sort((a: any, b: any) => b.totalMedals - a.totalMedals).slice(0, 5);
      this.chartData = [];
      this.chartLabels = [];
      sortedData.forEach((item: any) => {
        this.chartData.push(item.totalMedals);
        this.chartLabels.push(item.country);
      });
      this.createChart();
    }
  }
  onMedalSelectionChange(): void {
    if (this.selectedMedal === 'All') {
      this.chartData = this.allMedalData;
      this.chartLabels = this.allMedalLabels;
      this.createChart();
    } else {
      const medalData = this.medalData.filter((item: any) => this.selectedSport !== 'All' ? item?.medalType.toLowerCase() === this.selectedMedal.toLowerCase() && item?.sport.toLowerCase() === this.selectedSport.toLowerCase() : item?.medalType.toLowerCase() === this.selectedMedal.toLowerCase());
      const sortedData = medalData.sort((a: any, b: any) => b.count - a.count).slice(0, 3);
      this.chartData = [];
      this.chartLabels = [];
      sortedData.forEach((item: any) => {
        this.chartData.push(item.count);
        this.chartLabels.push(item.country);
      });
      this.createChart();
    }
  }
  

  createChart() {
    const canvas = document.getElementById('myChart') as HTMLCanvasElement;
    if (this.chart) {
      this.chart.destroy();
    }
    this.chart = new Chart(canvas, {
      type: this.chartType as ChartType,
      data: {
        labels: this.chartLabels,
        datasets: [
          {  
            label: 'Medals',
            data: this.chartData,
            backgroundColor: [
              'rgba(255, 99, 132, 0.2)',
              'rgba(54, 162, 235, 0.2)',
              'rgba(255, 206, 86, 0.2)',
            ],
            borderColor: [
              'rgba(255, 99, 132, 1)',
              'rgba(54, 162, 235, 1)',
              'rgba(255, 206, 86, 1)',
            ],
            borderWidth: 1,
          },
        ],
      },
      options: this.chartOptions,
    });
  }
}