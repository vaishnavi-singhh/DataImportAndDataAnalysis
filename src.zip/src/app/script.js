const graphsNav = document.querySelector('.graphs-nav');
const chartsNav = document.querySelector('.chart-nav');

graphsNav.addEventListener('click', () => {
  chartsNav.classList.toggle('active');
});
