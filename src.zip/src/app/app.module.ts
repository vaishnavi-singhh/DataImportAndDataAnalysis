import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import{Routes} from '@angular/router';
import {  HttpClientModule } from '@angular/common/http';
import { FetchTeamsComponent } from './FetchData/fetch-teams/fetch-teams.component';
import { FetchPlayersComponent } from './FetchData/fetch-players/fetch-players.component';
import { FetchCoachesComponent } from './FetchData/fetch-coaches/fetch-coaches.component';
import { FetchMedalsComponent } from './FetchData/fetch-medals/fetch-medals.component';
import { FileUploadComponent } from './UploadFile/teams-file-upload/file-upload.component';
import { PlayersFileUploadComponent } from './UploadFile/players-file-upload/players-file-upload.component';
import { CoachesFileUploadComponent } from './UploadFile/coaches-file-upload/coaches-file-upload.component';
import { MedalsFileUploadComponent } from './UploadFile/medals-file-upload/medals-file-upload.component';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { ChartModule } from '@syncfusion/ej2-angular-charts';
import { TopNationsChartComponent } from './Charts/top-nations-chart/top-nations-chart.component';
import { MedalsChartComponent } from './Charts/medals-chart/medals-chart.component';
import { GenderChartComponent } from './Charts/gender-chart/gender-chart.component';
import { PieChartComponent } from './Charts/pie-chart/pie-chart.component';
import { ToastrModule } from 'ngx-toastr';
import { NgxPaginationModule } from 'ngx-pagination';


const myRoute:Routes=[
  {path:'TeamsFileUpload', component:FileUploadComponent },  //TeamsFileUpload is a url of File Upload component
  {path:'PlayersFileUpload', component:PlayersFileUploadComponent },
  {path:'CoachesFileUpload', component:CoachesFileUploadComponent},
  {path:'MedalsFileUpload', component:MedalsFileUploadComponent},
  {path:'FetchTeamsData', component: FetchTeamsComponent},
  {path:'FetchPlayersData', component: FetchPlayersComponent},
  {path:'FetchCoachData', component: FetchCoachesComponent},
  {path:'FetchMedalsData', component: FetchMedalsComponent},
  {path:'TopNationsChart', component: TopNationsChartComponent},
  {path:'MedalsChart', component: MedalsChartComponent},
  {path:'GenderChart', component: GenderChartComponent},
  {path:'PieChart', component: PieChartComponent}

]

@NgModule({
  declarations: [
    AppComponent,
    FetchTeamsComponent,FetchPlayersComponent, FetchCoachesComponent,FetchMedalsComponent , 
    FileUploadComponent, PlayersFileUploadComponent, CoachesFileUploadComponent, MedalsFileUploadComponent,TopNationsChartComponent, MedalsChartComponent,GenderChartComponent,PieChartComponent
  ],

  imports: [
    BrowserModule, FormsModule, RouterModule.forRoot(myRoute), HttpClientModule,NgxChartsModule , ChartModule, ToastrModule.forRoot(), NgxPaginationModule
 
  ], 

  providers: [],
  bootstrap: [AppComponent] 
})    

export class AppModule { }
