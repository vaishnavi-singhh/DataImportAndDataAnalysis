import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { TeamService } from 'src/app/Service/Teams.Service';

@Component({
  selector: 'app-fetch-coaches',
  templateUrl: './fetch-coaches.component.html',
  styleUrls: ['./fetch-coaches.component.css'],
  providers:[TeamService]
})
export class FetchCoachesComponent {
 coachData: any[] = [];
  filteredCoachData: any[] = [];
  countryFilter: string = '';
  pageSizeOptions: number[] = [10, 25, 50, 100];
  pageSize: number = 100;
  currentPage: number = 1;
  updatedData: any;
  
  constructor(private teamService: TeamService) { }

  GetCoachData(form : NgForm): void
  {
    this.teamService.FetchCoachData(form).subscribe(data3 =>
    {
      console.log(data3);
      this.coachData = data3;
      this.filteredCoachData = data3;
        this.filterCoachData();
        this.currentPage = 1;
    },
      error => 
      {
        console.log(error);
      }
    );
  }
   filterByCountry() {
    this.filterCoachData();
    this.currentPage = 1;
  }

  private filterCoachData() {
    this.filteredCoachData = this.coachData.filter(coach => {
      if(coach?.country)
      return coach?.country.toLowerCase().includes(this.countryFilter.toLowerCase());
    });
    console.log(this.filteredCoachData)
    this.setPageSize();
  }

  setPageSize() {
    this.updatedData = this.filteredCoachData.slice(0, this.pageSize);
    this.currentPage = 1; // reset to first page after changing page size
  }
  

  get totalPages(): number {
    return Math.ceil(this.filteredCoachData.length / this.pageSize);
  }

  get teamsToDisplay(): any[] {
    const startIndex = (this.currentPage - 1) * this.pageSize;
    return this.filteredCoachData.slice(startIndex, startIndex + this.pageSize);
  }
}
