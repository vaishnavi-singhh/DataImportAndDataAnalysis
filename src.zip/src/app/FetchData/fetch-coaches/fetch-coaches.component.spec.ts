import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FetchCoachesComponent } from './fetch-coaches.component';

describe('FetchCoachesComponent', () => {
  let component: FetchCoachesComponent;
  let fixture: ComponentFixture<FetchCoachesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FetchCoachesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FetchCoachesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
