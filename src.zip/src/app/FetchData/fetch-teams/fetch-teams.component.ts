import { Component } from '@angular/core';
import { TeamService } from '../../Service/Teams.Service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-fetch-teams',
  templateUrl: './fetch-teams.component.html',
  styleUrls: ['./fetch-teams.component.css'],
  providers: [TeamService]
})
export class FetchTeamsComponent {
  teamsData: any[] = [];
  filteredTeamsData: any[] = [];
  countryFilter: string = '';
  pageSizeOptions: number[] = [25, 50, 75, 100];
  pageSize: number = 15;
  currentPage: number = 1;

  constructor(private teamService: TeamService) { }

  GetTeamsData(form: NgForm): void {
    this.teamService.FetchTeamsData(form).subscribe(
      data => {
        console.log(data);
        this.teamsData = data;
        this.filterTeamsData();
        this.currentPage = 1;
      },
      error => {
        console.log(error);
      }
    );
  }

  filterByCountry() {
    this.filterTeamsData();
    this.currentPage = 1;
  }

  private filterTeamsData() {
    this.filteredTeamsData = this.teamsData.filter(team => {
      return team.country.toLowerCase().includes(this.countryFilter.toLowerCase());
    });
  }   

  get totalPages(): number {
    return Math.ceil(this.filteredTeamsData.length / this.pageSize);
  }
  
  get teamsToDisplay(): any[] {
    const startIndex = (this.currentPage - 1) * this.pageSize;
    return this.filteredTeamsData.slice(startIndex, startIndex + this.pageSize);
  }

  goToPage(page: number): void {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
      console.log(this.currentPage)
    }
  }

  setPageSize(): void {
    this.currentPage = 1;
   
  }
}
