import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FetchTeamsComponent } from './fetch-teams.component';

describe('FetchTeamsComponent', () => {
  let component: FetchTeamsComponent;
  let fixture: ComponentFixture<FetchTeamsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FetchTeamsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FetchTeamsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
