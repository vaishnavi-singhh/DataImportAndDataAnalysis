import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Player } from 'src/app/Models/Players';
import { TeamService } from 'src/app/Service/Teams.Service';


@Component({
  selector: 'app-fetch-players',
  templateUrl: './fetch-players.component.html',
  styleUrls: ['./fetch-players.component.css'],
  providers: [TeamService]
})
export class FetchPlayersComponent {
  player = new Player();
  filteredPlayersData: any[] = [];
  countryFilter: string = '';
  sportFilter: string = '';
  playerName: string = '';
  pageSizeOptions: number[] = [25, 50, 75, 100];
  pageSize: number = 15;
  currentPage: number = 1;

  constructor(private teamService: TeamService) { }

  playersData: any;
 
  GetPlayersData(fetch: any): void
  {
    this.teamService.FetchPlayersData(fetch).subscribe(data1 =>
    {
      console.log(data1);
      this.playersData = data1;
      this.filteredPlayersData = data1;
      this.currentPage = 1;
     
    },
      error => 
      {
        console.log(error);
      }
    );
  } 

  filterPlayer(type: any) {
    this.filterData(type);
    this.currentPage = 1;
  }

  private filterData(type: any) {
    let filterType: any;
    switch(type) {
      case 'playerName':
      filterType = this.player.PlayerName;
      break;
      case 'country':
        filterType = this.player.Country;
        break;
      case 'sport':
        filterType = this.player.Sport;
        break;
    }
    this.playersData = this.filteredPlayersData.filter((player: any) => {
      if(player[type]) {
        return player[type].toLowerCase().includes(filterType.toLowerCase());
      }
      
    });
   
  }
  get totalPages(): number {
    return Math.ceil(this.playersData.length / this.pageSize);
  }
  
  get playersToDisplay(): any[] {
    const startIndex = (this.currentPage - 1) * this.pageSize;
    return this.playersData.slice(startIndex, startIndex + this.pageSize);
  }

  goToPage(page: number): void {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
      console.log(this.currentPage)
    }
  }

  setPageSize(): void {
    this.currentPage = 1;
   
  }
  
}


