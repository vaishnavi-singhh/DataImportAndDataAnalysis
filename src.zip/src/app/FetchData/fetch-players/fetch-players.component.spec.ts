import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FetchPlayersComponent } from './fetch-players.component';

describe('FetchPlayersComponent', () => {
  let component: FetchPlayersComponent;
  let fixture: ComponentFixture<FetchPlayersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FetchPlayersComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FetchPlayersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
