import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Medal } from 'src/app/Models/Medal';
import { TeamService } from 'src/app/Service/Teams.Service';

@Component({
  selector: 'app-fetch-medals',
  templateUrl: './fetch-medals.component.html',
  styleUrls: ['./fetch-medals.component.css'],
  providers: [TeamService]
})
export class FetchMedalsComponent {
  medalData: any[] = [];
   filteredMedalsData: any[] = [];
   countryFilter: string = '';
   pageSizeOptions: number[] = [10, 20, 30, 50];
  pageSize: number = 100;
  currentPage: number = 1;
  tempFilterData: any;

    constructor(private teamService: TeamService) { }
  
  
    GetMedalsData(form : NgForm): void
    {
      this.teamService.FetchMedalData(form).subscribe(data2 =>
      {
        console.log(data2);
        this.medalData = data2;
        this.filteredMedalsData = data2;
        this.filterMedalData();
        this.currentPage = 1;
      },
        error => 
        {
          console.log(error);
        }
      );
    }
    filterByCountry() {
      this.filterMedalData();
      this.currentPage = 1;
    }
  
    private filterMedalData() {
      this.tempFilterData = this.medalData.filter(medal => {
        return medal?.country.toLowerCase().includes(this.countryFilter.toLowerCase());
      });
      this.setPageSize();
    }
  
    setPageSize() {
       this.filteredMedalsData = this.tempFilterData.slice(0, this.pageSize);
    this.currentPage = 1; // reset to first page after changing page size
    }
    
  
    get totalPages(): number {
      return Math.ceil(this.filteredMedalsData.length / this.pageSize);
    }
  
    get teamsToDisplay(): any[] {
      const startIndex = (this.currentPage - 1) * this.pageSize;
      return this.filteredMedalsData.slice(startIndex, startIndex + this.pageSize);
    }
  
   
}
