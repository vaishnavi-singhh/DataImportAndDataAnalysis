import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FetchMedalsComponent } from './fetch-medals.component';

describe('FetchMedalsComponent', () => {
  let component: FetchMedalsComponent;
  let fixture: ComponentFixture<FetchMedalsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FetchMedalsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FetchMedalsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
