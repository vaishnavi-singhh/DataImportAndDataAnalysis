export class Coach
{   
    CoachId?: string
    CoachName?:string
    CoachAge?:number
    TeamId?: number
    TeamName?: string
    Country?: string
    Sport?: string

}  