export class Player 
{   
    PlayerId?: number
    PlayerName?: string
    Age?: number
    Gender?: string
    TeamId?: number
    TeamName?: string
    Country?: string
    Sport?: string
}
 