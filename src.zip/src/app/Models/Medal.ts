export class Medal 
{
    TeamId?: number
    TeamName?: string
    Country?: string
    Sport?: string
    Rank?:number
    Type?:string
}  