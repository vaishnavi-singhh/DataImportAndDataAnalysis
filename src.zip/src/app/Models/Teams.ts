export class Team 
{
    TeamId?: number
    TeamName?: string
    Country?: string
    Sport?: string
}  