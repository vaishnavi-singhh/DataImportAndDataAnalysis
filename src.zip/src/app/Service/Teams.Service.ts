import { HttpClient } from '@angular/common/http'
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable()

export class TeamService 
{
    fetch: any = 'http://localhost:5141/api/Team?pageNumber=1&pageSize=10';
    fetchPlayers : any = 'http://localhost:5141/api/Player/getplayer';
    fetchCoaches : any = 'http://localhost:5141/api/Coach';
    fetchMedals : any = 'http://localhost:5141/api/Medal/GetMedal';
  FetchTeamsDataFromBackend: any;

    constructor(private objhttp: HttpClient) 
    {

    }


    FetchTeamsData(Teamobj: any): Observable<any>
    {
        return this.objhttp.get<any>(this.fetch, Teamobj);
    }

    FetchPlayersData(Playerobj: any): Observable<any>
    {
        return this.objhttp.get<any>(this.fetchPlayers, Playerobj);
    }

    FetchCoachData(Coachobj: any): Observable<any>
    {
        return this.objhttp.get<any>(this.fetchCoaches, Coachobj);
    }

    FetchMedalData(Medalobj: any): Observable<any>
    {
        return this.objhttp.get<any>(this.fetchMedals, Medalobj);
    }
}  

